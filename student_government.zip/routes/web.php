<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;


Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/about', [App\Http\Controllers\AboutController::class, 'index'])->name('about');

Route::post('/about/submit', [App\Http\Controllers\AboutController::class, 'submit'])->name('request_submit');

Route::get('/schedule', [App\Http\Controllers\EventsController::class, 'schedule'])->name('schedule');

Route::get('/contact', [App\Http\Controllers\ContactController::class, 'index'])->name('contact');

Route::post('/contact/submit', [App\Http\Controllers\ContactController::class, 'submit'])->name('contact-form');

Route::post('/sg_control/add_ministry', [App\Http\Controllers\AdminController::class, 'admin_moder_add_ministry'])->name('add_ministry')->middleware(['auth', 'auth.moderator']);

Route::namespace('App\Http\Controllers\Admin')->middleware(['auth', 'auth.moderator'])->prefix('admin')->name('admin.')->group(function(){
    Route::resource('/users', 'UsersController', ['except' => ['show', 'create', 'store']])->middleware(['auth', 'auth.admin']);
    Route::resource('/roles', 'RolesController', ['except' => ['show', 'create', 'store', 'edit']])->middleware(['auth', 'auth.admin']);
    Route::resource('/students', 'StudentsController', ['except' => ['show', 'create', 'store']]);
    Route::resource('/specialties', 'SpecialtiesController', ['except' => ['show']]);
    Route::resource('/groups', 'GroupsController', ['except' => ['show']]);
    Route::resource('/ministries', 'MinistriesController', ['except' => ['show']]);
    Route::resource('/organizations', 'OrganizationsController', ['except' => ['show']]);
    Route::resource('/events', 'EventsController', ['except' => ['show']]);
    Route::resource('/student_requests', 'StudentRequestsController', ['except' => ['show', 'create', 'store']]);
    Route::resource('/contact_messages', 'ContactMessagesController', ['except' => ['show', 'create', 'store']]);
});

Route::resource('/profile', 'App\Http\Controllers\ProfileController', ['except'=>['index', 'create', 'destroy']]);

Auth::routes();
