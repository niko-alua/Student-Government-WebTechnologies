@extends('layouts.main')

@section('title-block')
    SG Main page
@endsection

@section('content')
    <div class="container">

        <!--Events section-->

        <section class="events">
            <div class="container">
                <div class="title">
                    <h2 class="text-center font-weight-bolder" style="font-family: 'Oswald'; font-size: xxx-large;">Schedule of events</h2>
                </div>
                <div class="events_list">
                    @foreach($events as $event)
                    <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                        <div class="col p-4 d-flex flex-column position-static">
                            <strong class="d-inline-block mb-2 text-primary">{{ $event->ministry->name }}</strong>
                            <h3 class="mb-0">{{ $event->name }}</h3>
                            <div class="mb-1 text-muted">{{ $event->date_time }}</div>
                            <p class="card-text mb-auto">{{ $event->description }}</p>
                        </div>
                    </div>
                    @endforeach
                    <hr style="border: 1px darkred solid;">

                </div>
            </div>
        </section>

        <!--Events section end-->

        <hr />

    </div>
@endsection
