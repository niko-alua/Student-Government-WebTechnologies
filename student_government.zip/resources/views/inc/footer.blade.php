<!--Footer section-->

<footer class="page-footer font-small blue pt-4" >
    <div class="container text-center text-md-left">
        <div class="row">
            <div class="col-sm-6 mt-sm-0 mt-3">
                <img src="https://sun9-40.userapi.com/impf/c850524/v850524692/5c7c/eVjUHwe1Qv4.jpg?size=200x0&quality=88&crop=195,0,665,665&sign=60791cee208035e81ff17ffd791977f7&ava=1" alt="logo" class="img-fluid" style="width: 190px; height:190px; object-fit:cover;">
            </div>

            <hr class="clearfix w-100 d-md-none pb-3">
    
            <div class="col-sm-3 mb-sm-0 mb-3">
                <ul class="list-unstyled">
                    <li><a class="text-dark" href="index.html">Home</a></li>
                    <li><a class="text-dark" href="#">Student Government</a></li>
                    <li><a class="text-dark" href="#">Events Schedule</a></li>
                    <li><a class="text-dark" href="gallery.html">Gallery</a></li>
                    <li><a class="text-dark" href="contacts.html">Contacts</a></li>
                    <li><a class="text-dark" href="#signInModal" data-toggle="modal">Sign In</a></li>
                </ul>
            </div>

            <div class="col-sm-3 mb-sm-0 mb-3">
                <ul class="list-unstyled">
                    <li><a class="text-dark" href=""><img src="" alt="">fb</a></li>
                    <li><a class="text-dark" href=""><img src="" alt="">inst</a></li>
                    <li><a class="text-dark" href=""><img src="" alt="">tw</a></li>
                    <li><a class="text-dark" href=""><img src="" alt="">vk</a></li>
                </ul>
            </div>
        </div>
    </div>


    <div class="footer-copyright text-center text-dark py-3">© 2020 Copyright:
        <a href="#" class="text-dark"> Alua/Erasyl</a>
    </div>
</footer>

<!--Footer section end-->