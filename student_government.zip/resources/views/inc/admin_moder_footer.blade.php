<footer class="footer mt-auto py-3">
    <div class="container text-center">
        <span class="text-muted">Copyright © 2020 by Kossaidarova A., Bakubayev Y.</span>
    </div>
</footer>