@extends('layouts.admin_moder')

@section('title-block')
    All Events
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Events</h2>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">
        Add
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Event</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('admin.events.store') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                            <div class="form-group">
                                <label>Name:</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Description:</label>
                                <textarea name="description" rows="5" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Date and time:</label>
                                <input type="datetime-local" name="date_time" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Place:</label>
                                <input type="text" name="place" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Ministry</label>
                                <select name="ministry_id" class="form-control">
                                    @foreach($ministries as $ministry)
                                    <option value="{{ $ministry->id }}">{{ $ministry->name }}</option>
                                    @endforeach()
                                </select>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th class = "text-uppercase" style="width: 5%;">Id</th>
            <th class = "text-uppercase" style="width: 10%;">Name</th>
            <th class = "text-uppercase" style="width: 20%;">Description</th>
            <th class = "text-uppercase" style="width: 25%;">Date and time</th>
            <th class = "text-uppercase" style="width: 15%;">Place</th>
            <th class = "text-uppercase" style="width: 10%;">Ministry</th>
            <th class = "text-uppercase" style="width: 15%;">Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($events as $event)
        <tr>
            <td>{{ $event->id }}</td>
            <td>{{ $event->name }}</td>
            <td>{{ $event->description }}</td>
            <td>{{ $event->date_time }}</td>
            <td>{{ $event->place }}</td>
            <td>{{ $event->ministry->name }}</td>
            <td>
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-success btn-sm float-left" data-toggle="modal" data-target="#exampleModal{{ $event->id }}">
                    Edit
                </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal{{ $event->id }}" tabindex="-1" aria-labelledby="exampleModalLabel{{ $event->id }}" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel{{ $event->id }}">Edit Event</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="{{ route('admin.events.update',['event' => $event->id]) }}" method="POST">
                                @csrf
                                {{ method_field('PUT') }}
                                <div class="modal-body">
                                        <div class="form-group">
                                            <label>Name:</label>
                                            <input type="text" name="name" class="form-control" value="{{ $event->name }}">
                                        </div>
                                        <div class="form-group">
                                            <label>Description:</label>
                                            <textarea name="description" rows="5" class="form-control">{{ $event->description }}</textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Date and time:</label>
                                            <input type="datetime-local" name="date_time" class="form-control" value="{{ $event->date_time }}">
                                        </div>
                                        <div class="form-group">
                                            <label>Place:</label>
                                            <input type="text" name="place" class="form-control" value="{{ $event->place }}">
                                        </div>
                                        <div class="form-group">
                                            <label>Ministry</label>
                                            <select name="ministry_id" class="form-control">
                                                @foreach($ministries as $ministry)
                                                <option value="{{ $ministry->id }}" {{ ($event->ministry->id == $ministry->id) ? 'selected':''}}>{{ $ministry->name }}</option>
                                                @endforeach()
                                            </select>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <form action="{{ route('admin.events.destroy', $event->id) }}" method="POST" class="float-left">
                    @csrf
                    {{ method_field('DELETE') }}
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection