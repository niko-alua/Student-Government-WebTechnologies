@extends('layouts.admin_moder')

@section('title-block')
    All Messages
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Students</h2>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th class = "text-uppercase">Name</th>
            <th class = "text-uppercase">Email</th>
            <th class = "text-uppercase">Phone Number</th>
            <th class = "text-uppercase">Group and course</th>
            <th class = "text-uppercase">Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($students as $student)
        <tr>
            <td>{{ $student->id }}</td>
            <td>{{ $student->user->name }}</td>
            <td>{{ $student->user->email }}</td>
            <td>{{ $student->phone_number }}</td>
            <td>{{ $student->group->specialty->code }} - {{ $student->group->number }}, {{ $student->course_number }} course</td>
            <td>
                <form action="{{ route('admin.students.destroy', $student->id) }}" method="POST">
                    @csrf
                    {{ method_field('DELETE') }}
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection