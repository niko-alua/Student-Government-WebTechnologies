@extends('layouts.admin_moder')

@section('title-block')
    All Students' Requests
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Students' Requests</h2>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th class = "text-uppercase">Id</th>
            <th class = "text-uppercase">Student</th>
            <th class = "text-uppercase">Organization</th>
            <th class = "text-uppercase">Message</th>
            <th class = "text-uppercase">Review</th>
        </tr>
    </thead>
    <tbody>
        @foreach($student_requests as $student_request)
        <tr>
            <td>{{ $student_request->id }}</td>
            <td>{{ $student_request->student($student_request->student_id)->user->name }}</td>
            <td>{{ $student_request->organization($student_request->organization_id)->name }}</td>
            <td>{{ $student_request->message }}</td>
            <td>
                @if(!$student_request->reviewed)
                <form action="{{ route ('admin.student_requests.update', ['student_request' => $student_request->id]) }}" method="POST">
                    @csrf
                    {{ method_field('PUT') }}
                    <button type="submit" class="btn btn-primary btn-sm" name="reviewed" value="1">Set reviewed</button>
                </form>
                @endif
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection