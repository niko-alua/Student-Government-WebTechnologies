@extends('layouts.admin_moder')

@section('title-block')
    All Specialties
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Specialties</h2>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">
        Add
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Specialty</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('admin.specialties.store') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                            <div class="form-group">
                                <label>Name:</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Code:</label>
                                <input type="text" name="code" class="form-control">
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th class = "text-uppercase">Id</th>
            <th class = "text-uppercase">Name</th>
            <th class = "text-uppercase">Code</th>
            <th class = "text-uppercase">Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($specialties as $specialty)
        <tr>
            <td>{{ $specialty->id }}</td>
            <td>{{ $specialty->name }}</td>
            <td>{{ $specialty->code }}</td>
            <td>
                <a href="{{ route('admin.specialties.edit', $specialty->id) }}" class="float-left">
                    <button type="button" class="btn btn-success btn-sm">Edit</button>
                </a>
                <form action="{{ route('admin.specialties.destroy', $specialty->id) }}" method="POST" class="float-left">
                    @csrf
                    {{ method_field('DELETE') }}
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection