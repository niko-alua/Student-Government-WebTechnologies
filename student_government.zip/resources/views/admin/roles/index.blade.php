@extends('layouts.admin_moder')

@section('title-block')
    All Roles
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Roles</h2>
</div>
<table class="table table-striped" style="width: 50%;">
    <thead>
        <tr>
            <th class = "text-uppercase" style="width: 50%;">Id</th>
            <th class = "text-uppercase" style="width: 50%;">Role</th>
        </tr>
    </thead>
    <tbody>
        @foreach($roles as $role)
        <tr>
            <td>{{ $role->id }}</td>
            <td>{{ $role->role }}</td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection