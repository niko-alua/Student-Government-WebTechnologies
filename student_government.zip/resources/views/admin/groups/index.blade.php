@extends('layouts.admin_moder')

@section('title-block')
    All Groups
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Groups</h2>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">
        Add
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Group</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('admin.groups.store') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                            <div class="form-group">
                                <label>Specialty:</label>
                                <select name="specialty_id" class="form-control">
                                    @foreach($specialties as $specialty)
                                    <option value="{{ $specialty->id }}">{{ $specialty->code }}</option>
                                    @endforeach()
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Number:</label>
                                <input type="text" name="number" class="form-control">
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th class = "text-uppercase">Specialty and Number</th>
            <th class = "text-uppercase">Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($groups as $group)
        <tr>
            <td>{{ $group->id }}</td>
            <td>{{ $group->specialty->code }} - {{ $group->number }}</td>
            <td>
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal{{ $group->id }}" class="float-left">
                    Edit
                </button>
                <!-- Modal -->
                <div class="modal fade" id="exampleModal{{ $group->id }}" tabindex="-1" aria-labelledby="exampleModalLabel{{ $group->id }}" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel{{ $group->id }}">Edit Group</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="{{ route('admin.groups.update', ['group' => $group->id]) }}" method="POST">
                                @csrf
                                {{ method_field('PUT') }}
                                <div class="modal-body">
                                        <div class="form-group">
                                            <label>Specialty:</label>
                                            <select name="specialty_id" class="form-control">
                                                @foreach($specialties as $specialty)
                                                <option value="{{ $specialty->id }}" {{ ($group->specialty->id == $specialty->id) ? 'selected':'' }}>{{ $specialty->code }}</option>
                                                @endforeach()
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Number:</label>
                                            <input type="text" name="number" class="form-control"value="{{ $group->number }}">
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <form action="{{ route('admin.groups.destroy', $group->id) }}" method="POST" class="float-left">
                    @csrf
                    {{ method_field('DELETE') }}
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection