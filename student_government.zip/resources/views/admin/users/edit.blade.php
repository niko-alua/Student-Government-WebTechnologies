@extends('layouts.admin_moder')

@section('title-block')
    Edit User
@endsection

@section('admin_moder_content')

<div class="card">
    <div class="card-body">
        <h5 class="card-title">{{ __('Name') }}</h5>
        <p>{{ $user->name }}</p>
        <h5 class="card-title">{{ __('Email') }}</h5>
        <p>{{ $user->email }}</p>
    </div>
    <div class="card-footer">
        <h5 class="card-title">{{ __('Roles') }}</h5>
        <form action="{{ route ('admin.users.update', ['user' => $user->id]) }}" method="POST">
            @csrf
            {{ method_field('PUT') }}
            @foreach ($roles as $role)
                <div class="form-check">
                    <input type="checkbox" name="roles[]" value="{{ $role->id  }}" {{ $user->hasAnyRole($role->role)?'checked':'' }}>
                    <label>{{ $role->role }}</label>
                </div>
            @endforeach
            <button type="submit" class="btn btn-success">
                Update
            </button>
        </form>
    </div>
</div>



@endsection