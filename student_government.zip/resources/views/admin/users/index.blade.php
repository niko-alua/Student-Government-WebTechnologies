@extends('layouts.admin_moder')

@section('title-block')
    All Users
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Users</h2>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th class = "text-uppercase">Name</th>
            <th class = "text-uppercase">Email</th>
            <th class = "text-uppercase">Roles</th>
            <th class = "text-uppercase">Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($users as $user)
        <tr>
            <td>{{ $user->id }}</td>
            <td>{{ $user->name }}</td>
            <td>{{ $user->email }}</td>
            <td>{{ implode(', ', $user->roles()->pluck('role')->toArray()) }}</td>
            <td>
                <a href="{{ route('admin.users.edit', $user->id) }}" class="float-left">
                    <button type="button" class="btn btn-success btn-sm">Edit</button>
                </a>
                <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST" class="float-left">
                    @csrf
                    {{ method_field('DELETE') }}
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection