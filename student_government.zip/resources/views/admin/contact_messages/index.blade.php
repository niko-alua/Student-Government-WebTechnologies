@extends('layouts.admin_moder')

@section('title-block')
    All Messages
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Messages</h2>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th class = "text-uppercase">Name</th>
            <th class = "text-uppercase">Phone number</th>
            <th class = "text-uppercase">Email</th>
            <th class = "text-uppercase">Message</th>
            <th class = "text-uppercase">Answer</th>
        </tr>
    </thead>
    <tbody>
        @foreach($messages as $message)
        <tr>
            <td>{{ $message->id }}</td>
            <td>{{ $message->name }}</td>
            <td>{{ $message->phone_number }}</td>
            <td>{{ $message->email }}</td>
            <td>{{ $message->message }}</td>
            <td>
                @if(!$message->answered)
                <form action="{{ route ('admin.contact_messages.update', ['message' => $message->id]) }}" method="POST">
                    @csrf
                    {{ method_field('PUT') }}
                    <button type="submit" class="btn btn-primary btn-sm" name="answered" value="1">Set Answered</button>
                </form>
                @endif
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection