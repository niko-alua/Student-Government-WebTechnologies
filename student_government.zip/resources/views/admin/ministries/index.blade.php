@extends('layouts.admin_moder')

@section('title-block')
    All Ministries
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Ministries</h2>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">
        Add
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Ministry</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="{{ route('admin.ministries.store') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                            <div class="form-group">
                                <label>Name:</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Description:</label>
                                <textarea name="description" rows="5" class="form-control"></textarea>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th class = "text-uppercase" style="width: 5%;">Id</th>
            <th class = "text-uppercase" style="width: 25%;">Name</th>
            <th class = "text-uppercase" style="width: 50%;">Description</th>
            <th class = "text-uppercase" style="width: 20%;">Actions</th>
        </tr>
    </thead>
    <tbody>
        @foreach($ministries as $ministry)
        <tr>
            <td>{{ $ministry->id }}</td>
            <td>{{ $ministry->name }}</td>
            <td>{{ $ministry->description }}</td>
            <td>
                <a href="{{ route('admin.ministries.edit', $ministry->id) }}" class="float-left">
                    <button type="button" class="btn btn-success btn-sm">Edit</button>
                </a>
                <form action="{{ route('admin.ministries.destroy', $ministry->id) }}" method="POST" class="float-left">
                    @csrf
                    {{ method_field('DELETE') }}
                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

@endsection