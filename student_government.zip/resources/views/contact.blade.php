@extends('layouts.main')

@section('title-block')
    SG Contact page
@endsection


@section('content')

    <div class="container">
        
        <hr style="border: 1px white solid;">


        <!--Contacts section-->

        <section class="contact_main">

            <div class="title">
                <h1 class="text-center text-uppercase my-4" style="font-family: 'Oswald';">Contact us for more information</h1>
            </div>
            
            <div class="row justify-content-between align-items-center">
                <div class="embed-responsive embed-responsive-4by3 col-sm-8">
                    <iframe class="embed-responsive-item" id="gmap_canvas" src="https://maps.google.com/maps?q=international%20information%20technologies%20university&t=&z=15&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                </div>
                <div class="col-md-3 text-center text-dark">
                    <ul class="list-unstyled mb-0">
                        <li><i class="fas fa-map-marker-alt fa-2x"></i>
                            <p>Manasa street 34A, Almaty, Kazakhstan</p>
                        </li>
                        <li>
                            <i class="fas fa-phone mt-4 fa-2x"></i>
                            <p>Telephone : +1 800 603 6035</p>
                        </li>
                        <li>
                            <i class="fas fa-envelope mt-4 fa-2x"></i>
                            <p>E-mail : info(at)company.com</p>
                        </li>
                    </ul>
                </div>
                
            </div>
                
            <div class = "w-75 mt-4 mx-auto">
                <h4 class="text-center text-dark">
                    Fill this form and we will contact you soon!
                </h4>
                
                <form action="{{route('contact-form')}}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label class="text-dark">Your name</label>
                        <input type="text" class="form-control" placeholder="Input your name" name="name" value="{{(Auth::user()&&Auth::user()->student!= null)?(Auth::user()->name):null}}">
                    </div>
                    <div class="form-group">
                        <label class="text-dark">Your phone number</label>
                        <input type="text" class="form-control" placeholder="Input your phone" name="phone_number" value="{{(Auth::user()&&Auth::user()->student!= null)?(Auth::user()->student->phone_number):null}}">
                    </div>
                    <div class="form-group">
                        <label class="text-dark">Your e-mail address</label>
                        <input type="email" class="form-control" placeholder="Input your e-mail address" name="email" value="{{(Auth::user()&&Auth::user()->student!= null)?(Auth::user()->email):null}}">
                    </div>
                    <div class="form-group">
                        <label class="text-dark">Your question or message</label>
                        <textarea class="form-control" placeholder="Input your message" style="height:200px" name="message"></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary text-white" style = "background-color: darkred; border-color: darkred;" >Submit</button>
                </form>
            </div>
        </section>

        <!--Contacts section end-->


        <hr style="border: 1px white solid;">

    </div>

@endsection