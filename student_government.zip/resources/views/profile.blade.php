@extends('layouts.main')

@section('title-block')
    SG Contact page
@endsection


@section('content')

    <div class="container">
        
        <hr style="border: 1px white solid;">


        <div class="title">
            <h1 class="text-center text-uppercase my-4" style="font-family: 'Oswald';">Profile</h1>
        </div>

        <div class="card card-body bg-white" style="background-color:rgba(0, 0, 0, 0.5);">
            <div class="form-row mb-4">
                <div class="col">
                    <label>Name</label>
                    <input type="text" class="form-control" value="{{ $user->name }}" readonly>
                </div>
                <div class="col">
                    <label>Email</label>
                    <input type="email" class="form-control" value="{{ $user->email }}" readonly>
                </div>
            </div>
            <h3 class="text-center text-uppercase" style="font-family: 'Oswald';">Student data</h3>
            <hr/>
            @if($student == null) 
            <form action="{{ route('profile.store') }}" method="POST">
            @csrf
                <div class="form-row mb-4">
                    <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
                    <div class="col">
                        <label>Phone number</label>
                        <input type="text" class="form-control" name="phone_number">
                    </div>
                    <div class="col">
                        <label>Course number</label>
                        <input type="number" min = "1" max = "5" class="form-control" name="course_number">
                    </div>
                    <div class="col">
                        <label>Group</label>
                        <select name="group_id" class="form-control">
                            @foreach($groups as $group)
                            <option value="{{ $group->id }}" >{{ $group->specialty->code }} - {{ $group->number }}</option>
                            @endforeach()
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-outline-dark">Become Student</button>
            </form>
            @endif

            @if($student != null) 
            <form action="{{ route('profile.update', Auth::user()->id) }}" method="POST">
            @csrf
                <div class="form-row mb-4">
                    <div class="col">
                        <label>Phone number</label>
                        <input type="text" class="form-control" name="phone_number" value="{{ $student->phone_number }}">
                    </div>
                    <div class="col">
                        <label>Course number</label>
                        <input type="number" min = "1" max = "5" class="form-control" name="course_number" value="{{ $student->course_number }}">
                    </div>
                    <div class="col">
                        <label>Group</label>
                        <select name="group_id" class="form-control">
                            @foreach($groups as $group)
                            <option value="{{ $group->id }}" {{ ($student->group->id == $group->id) ? 'selected' : '' }}>{{ $group->specialty->code }} - {{ $group->number }}</option>
                            @endforeach()
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-outline-dark">Update data</button>
            </form>
            @endif
        </div>
    </div>

@endsection