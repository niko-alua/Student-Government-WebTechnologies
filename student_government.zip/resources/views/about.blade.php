@extends('layouts.main')

@section('title-block')
    SG About page
@endsection

@section('content')

<div class="container">
    <h1 class="text-center text-uppercase">Student organizations</h1>
    <hr/>
    <p>IITU pays special attention to the development of students’ personal qualities, leadership skills and creative abilities. The students also strive to make their university life brighter and unforgettable. The most active and talented students independently conduct various events and lead projects that cause admiration and surprise. That is why every day at IITU is a holiday.</p>
    <hr/>
    <img src="https://iitu.kz/media/images/3XgzGR9BdU8.original.jpg" alt="img" class="img-fluid" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <p><b>The President</b> is the leader of all IITU activists. There are 4 organizations registered at the university including a student government and 16 clubs. Among them are intellectual clubs, sports teams, charitable organizations and circles that promote individual and collective creative realization of a person.</p>
    <img src="https://iitu.kz/media/images/photo_2020-03-30_12-03-31.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <p>Each ministry is responsible for the development of a specific area. For example, <b>the Ministry of Culture</b> is responsible for organizing various events for students and guests (KVN, dance club “Shadows”, music club, cinema club, student theaters and an ensemble of national instruments) The Ministry of Culture also organizes various theme parties where students can have fun and relax after classes, as well as celebrate different holidays.</p>
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-53-03.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-51-22.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-52-23_2.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <p><b>The Ministry of Science and Education</b> conducts various master classes, tournaments, Olympiads, intellectual quests and language clubs. There are also debate clubs at the university.</p>
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-48-46.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <p>
    In addition, the university has a student <b>information and entertainment publishing called MAG’n’IT</b>. The students have their own media and PR services. They independently conduct career counseling for schools. All this is the responsibility of <b>the Ministry of Media and PR</b>.
    </p>
    <p>
        There is a <b>Security Service</b> responsible for the safety of students.
    </p>
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-48-46.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <img src="https://iitu.kz/media/images/photo_2020-03-30_11-59-37.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <p>We have real champions in <b>the Ministry of Sports</b>. Among them is IT Cheerleaders team that became champions of the Republic of Kazakhstan among universities at the championship of the Kazakhstan National Cheerleading Federation. Also there is IT Legion Fan Club, the best and most active sports fans, and the League of IT, a team of organizers of the university football League.</p>
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-54-11.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-49-50.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-48-08.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <p>Students participate in such organizations as the charity <b>Union, Tigers and the League of Volunteers</b>. In addition, the Senate, which is the link between students and the dean’s office was created in IITU.</p>
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-43-39.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <img src="https://iitu.kz/media/images/photo_2020-03-30_10-47-03.original.jpg" alt="img" style="display: block;
    margin-left: auto;
    margin-right: auto; max-width:100%;">
    <p>
    We can talk about IITU student life forever. Every semester there is something new and unforgettable. Education in IITU is an ideal platform for student development and a guarantee of happy and unforgettable student life.
    </p>

    @auth

    @if(Auth::user()->student != null)

    <div class = "w-75 mt-4 mx-auto">
        <h4 class="text-center text-dark">
            Fill this form to send the request to become a member of organization!
        </h4>
        
        <form action="{{route('request_submit')}}" method="POST">
            @csrf
            <input type="hidden" name="student_id" value="{{ Auth::user()->student->id }}">
            <div class="form-group">
                <label class="text-dark">Organization</label>
                <select class="form-control" name ="organization_id">
                    @foreach($organizations as $organization)
                    <option value="{{ $organization->id }}">{{ $organization->name }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label class="text-dark">Message</label>
                <textarea name="message" rows="5" class="form-control"></textarea>
            </div>
            <button type="submit" class="btn btn-primary text-white" style = "background-color: darkred; border-color: darkred;" >Submit</button>
        </form>
    </div>

    @endif

    @if(Auth::user()->student == null)

    <h3 class="text-center">Become student from your profile page to send request!</h3>

    @endif

    @endauth

    @guest

    <h3 class="text-center"><a href="{{ route('login') }}">Login</a> or <a href="{{ route('register') }}">Register</a> to send request!</h3>
    
    @endguest

</div>


@endsection
