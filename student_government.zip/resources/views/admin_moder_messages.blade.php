@extends('layouts.admin_moder')

@section('title-block')
    All Messages
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Messages</h2>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th class = "text-uppercase">Name</th>
            <th class = "text-uppercase">Phone number</th>
            <th class = "text-uppercase">Email</th>
            <th class = "text-uppercase">Message</th>
            <th class = "text-uppercase">Details</th>
        </tr>
    </thead>
    <tbody>
        @foreach($messages as $message)
        <tr>
            <td>{{ $message->id }}</td>
            <td>{{ $message->name }}</td>
            <td>{{ $message->phone_number }}</td>
            <td>{{ $message->email }}</td>
            <td>{{ $message->message }}</td>
            <td>
                <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#messageDetails"><i class="fas fa-info"></i></button>
            </td>
            <!--
            <div class="modal fade" th:id="messageDetails" tabindex="-1" role="dialog" aria-labelledby="messageDetailsTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="messageDetailsTitle">Message details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="" method="post" accept-charset="UTF-8">
                            <div class="modal-body">
                                <input type="hidden" name = "" value="">
                                <div class="form-group">
                                    <label class="text-uppercase"></label>
                                    <input type="text" class="form-control" name="" value="" readonly>
                                </div>
                                <div class="form-group">
                                    <label class="text-uppercase"></label>
                                    <input type="text" class="form-control" name="" value="" readonly>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            -->
        </tr>
        @endforeach
    </tbody>
</table>

@endsection