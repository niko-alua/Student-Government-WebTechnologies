@extends('layouts.admin_moder')

@section('title-block')
    All Messages
@endsection

@section('admin_moder_content')

<div class="d-flex justify-content-between align-items-center">
    <h2>Messages</h2>
    <button type="button" class="btn btn-dark text-uppercase" data-toggle="modal" data-target="#addMinistry"><i class="fas fa-plus"></i> Add</button>
    <div class="modal fade" id="addMinistry" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Add Ministry</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="{{ route('add_ministry') }}" method="post" accept-charset="UTF-8">
                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="text-uppercase">Name</label>
                            <input type="text" class="form-control" name="name">
                        </div>
                        <div class="form-group">
                            <label class="text-uppercase">Description</label>
                            <textarea class="form-control" name="description"></textarea>
                        </div>
                    </div>
                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success text-uppercase">Add</button>
                        <button type="button" class="btn btn-danger text-uppercase" data-dismiss="modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th class = "text-uppercase">Name</th>
            <th class = "text-uppercase">Description</th>
            <th class = "text-uppercase">Edit</th>
        </tr>
    </thead>
    <tbody>
        @foreach($ministries as $ministry)
        <tr>
            <td>{{ $message->id }}</td>
            <td>{{ $message->name }}</td>
            <td>{{ $message->description }}</td>
            <td>
                <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#editMinistry"><i class="fas fa-edit"></i></button>
            </td>
            <!--
            <div class="modal fade" th:id="editMinistry" tabindex="-1" role="dialog" aria-labelledby="editMinistryTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editMinistryTitle">Edit ministry</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="" method="post" accept-charset="UTF-8">
                            <div class="modal-body">
                                <input type="hidden" name = "" value="">
                                <div class="form-group">
                                    <label class="text-uppercase"></label>
                                    <input type="text" class="form-control" name="" value="" readonly>
                                </div>
                                <div class="form-group">
                                    <label class="text-uppercase"></label>
                                    <input type="text" class="form-control" name="" value="" readonly>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            -->
        </tr>
        @endforeach
    </tbody>
</table>

@endsection