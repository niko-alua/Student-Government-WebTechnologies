<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    public function organizations()
    {
        return $this->belongsToMany(Organization::class);
    }

    public function group()
    {
        return $this->belongsTo(Group::class);
    }

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function student_requests(){
        return $this->belongsToMany(StudentRequest::class);
    }
}
