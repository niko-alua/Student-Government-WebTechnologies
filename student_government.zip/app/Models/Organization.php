<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Organization extends Model
{
    use HasFactory;

    public function students()
    {
        return $this->belongsToMany(Student::class);
    }

    public function ministry()
    {
        return $this->belongsTo(Ministry::class);
    }

    public function student_requests(){
        return $this->belongsToMany(StudentRequest::class);
    }
}
