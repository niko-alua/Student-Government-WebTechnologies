<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentRequest extends Model
{
    use HasFactory;

    public function students(){
        return $this->hasMany(Student::class);
    }
    
    public function organizations(){
        return $this->hasMany(Organization::class);
    }

    public function student($id) {
        $student = Student::find($id);
        return $student;
    }

    public function organization($id) {
        $organization = Organization::find($id);
        return $organization;
    }
}
