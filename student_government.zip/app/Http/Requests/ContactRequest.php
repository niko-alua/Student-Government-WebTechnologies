<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ContactRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required',
            'phone_number' => 'min:11|max:12',
            'email' => 'required|email',
            'message' => 'required'
        ];
    }


    public function messages()
    {
        return [
            'name.required' => 'You should input your name',
            'email.required' => 'You should input your email',
            'message.required' => 'You should input your message or question',
            'email.email' => 'Wrong email format'
        ];
    }
}
