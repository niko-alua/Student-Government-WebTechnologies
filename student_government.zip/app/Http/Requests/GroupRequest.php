<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class GroupRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'specialty_id' => 'required',
            'number' => 'required'
        ];
    }

    public function messages()
    {
        return [
            'name.specialty_id' => 'You should choose specialty',
            'number.required' => 'You should input group number'
        ];
    }
}
