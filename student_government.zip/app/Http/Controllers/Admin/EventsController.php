<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Ministry;
use Illuminate\Http\Request;

class EventsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view("admin.events.index")->with(['events' => Event::all(), 'ministries' => Ministry::all()]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $event = new Event();
        $event->name = $request->input('name');
        $event->description = $request->input('description');
        $event->date_time = $request->input('date_time');
        $event->place = $request->input('place');
        $event->ministry_id = $request->input('ministry_id');

        $event->save();

        return redirect()->route('admin.events.index')->with('success', 'Event had been added!');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $event = Event::find($id);
        if($event == null) {
            return redirect()->route('admin.events.index')->with('warning', 'Event does not exist!');
        }
        $event->name = $request->input('name');
        $event->description = $request->input('description');
        $event->date_time = $request->input('date_time');
        $event->place = $request->input('place');
        $event->ministry_id = $request->input('ministry_id');

        $event->save();

        return redirect()->route('admin.events.index')->with('success', 'Event had been added!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Event::destroy($id);

        return redirect()->route('admin.events.index')->with('success', 'Event had been deleted!');
    }
}
