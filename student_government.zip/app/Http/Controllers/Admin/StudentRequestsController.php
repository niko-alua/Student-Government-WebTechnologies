<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\StudentRequest;
use Illuminate\Http\Request;

class StudentRequestsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $student_requests = StudentRequest::All();
        return view('admin.student_requests.index')->with('student_requests', $student_requests);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $student_request = StudentRequest::find($id);

        $reviewed = $request->input('reviewed');
        if($reviewed == 1){
            $student_request->reviewed = true;
        }
        $student_request -> save();

        return redirect()->route('admin.student_requests.index') -> with('success', 'Request had been reviewed!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
