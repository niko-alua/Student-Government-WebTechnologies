<?php

namespace App\Http\Controllers;

use App\Models\Event;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class EventsController extends Controller
{
    public function schedule()
    {
        $events = Event::all();
        return view('schedule', ['events' => $events]);
    }
}
