<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\ContactRequest;
use App\Models\ContactMessage;

class ContactController extends Controller {
    public function index(){
        return view('contact');
    }

    public function submit(ContactRequest $request) {
        $message = new ContactMessage();
        $message->name = $request->input('name');
        $message->phone_number = $request->input('phone_number');
        $message->email = $request->input('email');
        $message->message = $request->input('message');

        $message->save();

        return redirect()->route('home')->with('success', 'Your message was successfully sent!');
    }
}