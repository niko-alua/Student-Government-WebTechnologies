<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ministry;
use App\Models\Student;
use App\Models\Organization;
use App\Models\ContactMessage;
use App\Models\StudentRequest;
use Illuminate\Support\Facades\Auth;

class AboutController extends Controller
{
    public function index(){
        $organizations = Organization::all();
        return view('about', ['organizations' => $organizations]);
    }

    public function submit(Request $request) {
        $student_request = new StudentRequest();
        $student_request->student_id = $request->input('student_id');
        $student_request->organization_id = $request->input('organization_id');
        $student_request->message = $request->input('message');

        $student_request->save();
        return redirect()->route('home')->with('success', 'Your message was successfully sent!');
    }
}
