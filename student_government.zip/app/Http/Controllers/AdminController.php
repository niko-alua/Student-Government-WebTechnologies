<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Event;
use App\Models\ContactMessage;
use App\Models\Ministry;
use App\Models\Organization;
use App\Models\Role;
use App\Models\Specialty;
use App\Models\Student;
use App\Models\Group;
use App\Models\StudentRequest;
use App\Models\User;
use App\Http\Requests\MinistryRequest;
use App\Http\Requests\RoleRequest;
use App\Http\Requests\SpecialtyRequest;
use App\Http\Requests\GroupRequest;
use App\Http\Requests\OrganizationRequest;

class AdminController extends Controller
{
    public function admin_users() {
        $users = User::all();
        return view('admin_moder_users', ['users' => $users]);
    }

    public function admin_moder_roles() {
        $roles = Role::all();
        return view('admin_moder_roles', ['roles' => $roles]);
    }

    public function admin_moder_students() {
        $students = Student::all();
        return view('admin_moder_students', ['students' => $students]);
    }

    public function admin_moder_specialties() {
        $specialties = Specialty::all();
        return view('admin_moder_specialties', ['specialties' => $specialties]);
    }

    public function admin_add_specialty(SpecialtyRequest $request) {
        $specialty = new Specialty();
        $specialty->name = $request->input('name');
        $specialty->code = $request->input('code');

        $specialty->save();
        
        return redirect()->route('admin_moder_specialties');
    }

    public function admin_moder_groups() {
        $groups = Group::all();
        return view('admin_moder_groups', ['groups' => $groups]);
    }

    public function admin_add_group(GroupRequest $request) {
        $group = new Group();
        $group->specialty_id = $request->input('specialty_id');
        $group->number = $request->input('number');

        $group->save();
        
        return redirect()->route('admin_moder_specialties');
    }

    public function admin_moder_ministries() {
        $ministries = Ministry::all();
        return view('admin_moder_ministries', ['ministries' => $ministries]);
    }

    public function admin_moder_add_ministry(MinistryRequest $request) {
        $ministry = new Ministry();
        $ministry->name = $request->input('name');
        $ministry->description = $request->input('description');

        $ministry->save();
        
        return redirect()->route('admin_moder_ministries');
    }

    public function admin_moder_organizations() {
        $organizations = Organization::all();
        return view('admin_moder_organizations', ['organizations' => $organizations]);
    }

    public function admin_moder_add_organization(OrganizationRequest $request) {
        $organization = new Organization();
        $organization->name = $request->input('name');
        $organization->description = $request->input('description');
        $organization->ministry_id = $request->input('ministry_id');

        $organization->save();
        
        return redirect()->route('admin_moder_ministries');
    }

    public function admin_moder_events() {
        $events = Event::all();
        return view('admin_moder_events', ['events' => $events]);
    }

    public function admin_moder_student_requests() {
        $student_requests = StudentRequest::all();
        return view('admin_moder_student_requests', ['student_requests' => $student_requests]);
    }

    public function admin_moder_messages(){
        $messages = ContactMessage::all();
        
        return view('admin_moder_messages', ['messages' => $messages]);
    }
}
