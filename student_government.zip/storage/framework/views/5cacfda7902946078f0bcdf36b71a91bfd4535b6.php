

<?php $__env->startSection('title-block'); ?>
    All Students' Requests
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_moder_content'); ?>

<div class="d-flex justify-content-between align-items-center">
    <h2>Students' Requests</h2>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th class = "text-uppercase">Id</th>
            <th class = "text-uppercase">Student</th>
            <th class = "text-uppercase">Organization</th>
            <th class = "text-uppercase">Message</th>
            <th class = "text-uppercase">Review</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $student_requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student_request->id); ?></td>
            <td><?php echo e($student_request->student($student_request->student_id)->user->name); ?></td>
            <td><?php echo e($student_request->organization($student_request->organization_id)->name); ?></td>
            <td><?php echo e($student_request->message); ?></td>
            <td>
                <?php if(!$student_request->reviewed): ?>
                <form action="<?php echo e(route ('admin.student_requests.update', ['student_request' => $student_request->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <button type="submit" class="btn btn-primary btn-sm" name="reviewed" value="1">Set reviewed</button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_moder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/admin/student_requests/index.blade.php ENDPATH**/ ?>