

<?php $__env->startSection('title-block'); ?>
    SG Main page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!--Events section-->

        <section class="events">
            <div class="container">
                <div class="title">
                    <h2 class="text-center font-weight-bolder" style="font-family: 'Oswald'; font-size: xxx-large;">Schedule of events</h2>
                </div>
                <div class="events_list">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                        <div class="col p-4 d-flex flex-column position-static">
                            <strong class="d-inline-block mb-2 text-primary"><?php echo e($event->ministry->name); ?></strong>
                            <h3 class="mb-0"><?php echo e($event->name); ?></h3>
                            <div class="mb-1 text-muted"><?php echo e($event->date_time); ?></div>
                            <p class="card-text mb-auto"><?php echo e($event->description); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr style="border: 1px darkred solid;">

                </div>
            </div>
        </section>

        <!--Events section end-->

        <hr />

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/schedule.blade.php ENDPATH**/ ?>