

<?php $__env->startSection('title-block'); ?>
    All Events
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_moder_content'); ?>

<div class="d-flex justify-content-between align-items-center">
    <h2>Events</h2>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#exampleModal">
        Add
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Event</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.events.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                            <div class="form-group">
                                <label>Name:</label>
                                <input type="text" name="name" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Description:</label>
                                <textarea name="description" rows="5" class="form-control"></textarea>
                            </div>
                            <div class="form-group">
                                <label>Date and time:</label>
                                <input type="datetime-local" name="date_time" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Place:</label>
                                <input type="text" name="place" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Ministry</label>
                                <select name="ministry_id" class="form-control">
                                    <?php $__currentLoopData = $ministries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ministry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ministry->id); ?>"><?php echo e($ministry->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add</button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th class = "text-uppercase" style="width: 5%;">Id</th>
            <th class = "text-uppercase" style="width: 10%;">Name</th>
            <th class = "text-uppercase" style="width: 20%;">Description</th>
            <th class = "text-uppercase" style="width: 25%;">Date and time</th>
            <th class = "text-uppercase" style="width: 15%;">Place</th>
            <th class = "text-uppercase" style="width: 10%;">Ministry</th>
            <th class = "text-uppercase" style="width: 15%;">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($event->id); ?></td>
            <td><?php echo e($event->name); ?></td>
            <td><?php echo e($event->description); ?></td>
            <td><?php echo e($event->date_time); ?></td>
            <td><?php echo e($event->place); ?></td>
            <td><?php echo e($event->ministry->name); ?></td>
            <td>
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-success btn-sm float-left" data-toggle="modal" data-target="#exampleModal<?php echo e($event->id); ?>">
                    Edit
                </button>

                <!-- Modal -->
                <div class="modal fade" id="exampleModal<?php echo e($event->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel<?php echo e($event->id); ?>" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel<?php echo e($event->id); ?>">Edit Event</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form action="<?php echo e(route('admin.events.update',['event' => $event->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('PUT')); ?>

                                <div class="modal-body">
                                        <div class="form-group">
                                            <label>Name:</label>
                                            <input type="text" name="name" class="form-control" value="<?php echo e($event->name); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Description:</label>
                                            <textarea name="description" rows="5" class="form-control"><?php echo e($event->description); ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Date and time:</label>
                                            <input type="datetime-local" name="date_time" class="form-control" value="<?php echo e($event->date_time); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Place:</label>
                                            <input type="text" name="place" class="form-control" value="<?php echo e($event->place); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label>Ministry</label>
                                            <select name="ministry_id" class="form-control">
                                                <?php $__currentLoopData = $ministries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ministry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($ministry->id); ?>" <?php echo e(($event->ministry->id == $ministry->id) ? 'selected':''); ?>><?php echo e($ministry->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Edit</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <form action="<?php echo e(route('admin.events.destroy', $event->id)); ?>" method="POST" class="float-left">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_moder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/admin/events/index.blade.php ENDPATH**/ ?>