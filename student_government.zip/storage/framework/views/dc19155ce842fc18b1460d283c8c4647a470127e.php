

<?php $__env->startSection('title-block'); ?>
    All Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_moder_content'); ?>

<div class="d-flex justify-content-between align-items-center">
    <h2>Users</h2>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th class = "text-uppercase">Name</th>
            <th class = "text-uppercase">Email</th>
            <th class = "text-uppercase">Roles</th>
            <th class = "text-uppercase">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->id); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e(implode(', ', $user->roles()->pluck('role')->toArray())); ?></td>
            <td>
                <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="float-left">
                    <button type="button" class="btn btn-success btn-sm">Edit</button>
                </a>
                <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="float-left">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_moder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/admin/users/index.blade.php ENDPATH**/ ?>