<div class="card">
    <div class="card-header bg-dark text-uppercase text-white font-weight-bolder">
        Dashboard
    </div>
    <div class="list-group list-group-flush">
        <?php if(Auth::user()->hasAnyRole('admin')): ?>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="list-group-item list-group-item-action">
            Users
        </a>
        <?php endif; ?>
        <?php if(Auth::user()->hasAnyRole('admin')): ?>
        <a href="<?php echo e(route('admin.roles.index')); ?>" class="list-group-item list-group-item-action">
            Roles
        </a>
        <?php endif; ?>
        <a href="<?php echo e(route('admin.students.index')); ?>" class="list-group-item list-group-item-action">
            Students
        </a>
        <a href="<?php echo e(route('admin.specialties.index')); ?>" class="list-group-item list-group-item-action">
            Specialties
        </a>
        <a href="<?php echo e(route('admin.groups.index')); ?>" class="list-group-item list-group-item-action">
            Groups
        </a>
        <a href="<?php echo e(route('admin.ministries.index')); ?>" class="list-group-item list-group-item-action">
            Ministries
        </a>
        <a href="<?php echo e(route('admin.organizations.index')); ?>" class="list-group-item list-group-item-action">
            Organizations
        </a>
        <a href="<?php echo e(route('admin.events.index')); ?>" class="list-group-item list-group-item-action">
            Events
        </a>
        <a href="<?php echo e(route('admin.student_requests.index')); ?>" class="list-group-item list-group-item-action">
            Students' requests
        </a>
        <a href="<?php echo e(route('admin.contact_messages.index')); ?>" class="list-group-item list-group-item-action">
            Messages
        </a>
    </div>
</div><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/inc/admin_moder_dashboard.blade.php ENDPATH**/ ?>