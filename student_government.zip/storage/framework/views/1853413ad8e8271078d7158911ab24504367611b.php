

<?php $__env->startSection('title-block'); ?>
    All Messages
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_moder_content'); ?>

<div class="d-flex justify-content-between align-items-center">
    <h2>Students</h2>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th class = "text-uppercase">Name</th>
            <th class = "text-uppercase">Email</th>
            <th class = "text-uppercase">Phone Number</th>
            <th class = "text-uppercase">Group and course</th>
            <th class = "text-uppercase">Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student->id); ?></td>
            <td><?php echo e($student->user->name); ?></td>
            <td><?php echo e($student->user->email); ?></td>
            <td><?php echo e($student->phone_number); ?></td>
            <td><?php echo e($student->group->specialty->code); ?> - <?php echo e($student->group->number); ?>, <?php echo e($student->course_number); ?> course</td>
            <td>
                <form action="<?php echo e(route('admin.students.destroy', $student->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('DELETE')); ?>

                    <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_moder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/admin/students/index.blade.php ENDPATH**/ ?>