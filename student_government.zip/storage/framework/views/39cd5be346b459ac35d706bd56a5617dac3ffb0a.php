

<?php $__env->startSection('title-block'); ?>
    SG Main page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <!--Banner section. Information banner about university and its inner life or like addvertisement of unversity, or quote.-->
        
        <section class="banner">
            <div class="row align-items-center justify-content-center" 
            style="background: linear-gradient( rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5) ), url('https://iitu.kz/media/images/photo_2020-03-30_10-49-50.original.jpg');background-position:center top;
            background-repeat: no-repeat;background-attachment: fixed; background-size: cover;">
                <div class="col-sm-8 my-5" >
                    <div class="text-white text-center font-weight-bold">
                        <h1 class="display-4" style="font-family: 'Monoton', cursive;">International information technologies university</h1>
                        <p>
                        International University of Information Technology - was established in April 2009 on behalf of the President of the Republic of Kazakhstan, in cooperation with the educational organization iCarnegie, representing the American IT University Carnegie Mellon University.
                        </p>
                        <a href="<?php echo e(route ('about')); ?>" class="btn btn-light" role="button">Read more</a>  <!--Scrolles the main page to the -->
                    </div>
                </div>
            </div>
        </section>

        <!--Banner section end-->

        <hr style="border: 1px white solid;">


        <!--Events section-->

        <section class="events">
            <div class="container">
                <div class="title">
                    <h2 class="text-center font-weight-bolder" style="font-family: 'Oswald'; font-size: xxx-large;">Schedule of holidays</h2>
                </div>
                <div class="events_list">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row no-gutters border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
                        <div class="col p-4 d-flex flex-column position-static">
                            <strong class="d-inline-block mb-2 text-primary"><?php echo e($event->ministry->name); ?></strong>
                            <h3 class="mb-0"><?php echo e($event->name); ?></h3>
                            <div class="mb-1 text-muted"><?php echo e($event->date_time); ?></div>
                            <p class="card-text mb-auto"><?php echo e($event->description); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr style="border: 1px darkred solid;">

                </div>
            </div>
        </section>

        <!--Events section end-->


        <!--Student Organizations section-->

        <section class="stud_org my-5">

            <div class="container">
                <a href="#stud_ministries" data-toggle="collapse" class="btn text-dark bg-light w-100 my-4"><h2>Want to be part of it? &gt;</h2></a>
            
                <div id="stud_ministries" class="collapse text-dark">
                    <div class="row row-cols-4">
                        <?php $__currentLoopData = $ministries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ministry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card-transparent col">
                            <h4 class="card-title text-center"><?php echo e($ministry->name); ?></h4>
                            <div class="card-body">
                                <p><?php echo e($ministry->description); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
        
                    <div class="add_video">
                        <h3 class="text-center text-uppercase" style="font-family: 'Monoton', cursive;"><a href="<?php echo e(route ('about')); ?>" class="text-dark">More about university&gt;&gt;</a></h3>
                        <div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="https://www.youtube.com/embed/PJE2V8dX_Yk" allowfullscreen></iframe></div>
                    </div>
                </div>
            
            </div>
            
        </section>

        <!--Student Organizations section end-->

        <hr style="border: 1px white solid;">

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/home.blade.php ENDPATH**/ ?>