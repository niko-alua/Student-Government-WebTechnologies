<footer class="footer mt-auto py-3">
    <div class="container text-center">
        <span class="text-muted">Copyright © 2020 by Kossaidarova A., Bakubayev Y.</span>
    </div>
</footer><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/inc/admin_moder_footer.blade.php ENDPATH**/ ?>