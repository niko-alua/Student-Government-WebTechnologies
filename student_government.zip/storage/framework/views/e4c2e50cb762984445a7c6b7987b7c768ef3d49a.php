<!--Header section-->
        
<header>
    <nav class="navbar navbar-light navbar-expand-lg">
        <a class="navbar-brand text-dark" href="index.html">
            <img src="https://sun9-38.userapi.com/c849232/v849232361/7d972/Vj_uXm3cA9I.jpg" alt="logo" class="img-fluid" style="height:66px; object-fit: cover;">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end"  id="navbarSupportedContent">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link text-dark text-uppercase font-weight-bolder" href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="nav-item"><a class="nav-link text-dark text-uppercase font-weight-bolder" href="<?php echo e(route('about')); ?>">Student Government</a></li>
                <li class="nav-item"><a class="nav-link text-dark text-uppercase font-weight-bolder" href="<?php echo e(route('schedule')); ?>">Events Schedule</a></li>
                <li class="nav-item"><a class="nav-link text-dark text-uppercase font-weight-bolder" href="<?php echo e(route('contact')); ?>">Contact</a></li>
                <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item"><a class="nav-link text-dark text-uppercase font-weight-bolder" href="<?php echo e(route('login')); ?>">Sign In</a></li>
                <li class="nav-item"><a class="nav-link text-dark text-uppercase font-weight-bolder" href="<?php echo e(route('register')); ?>">Register</a></li>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>

                <?php if(Auth::user()->hasAnyRole('admin') || Auth::user()->hasAnyRole('moderator')): ?>

                <li class="nav-item"><a class="nav-link text-dark text-uppercase font-weight-bolder" href="<?php echo e(route('admin.users.index')); ?>">Admin Panel</a></li>
                
                <?php endif; ?>

                <li class="nav-item">
                    <div class="dropdown">
                        <button class="btn dropdown-toggle text-dark text-uppercase font-weight-bolder" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?>

                        </button>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item text-uppercase" href="<?php echo e(route('profile.show', Auth::user()->id)); ?>">Profile</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item text-uppercase"  href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">Logout</a>
                        </div>
                    </div>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form>
    </nav>
</header>
        
<!-- Header section end --><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/inc/header.blade.php ENDPATH**/ ?>