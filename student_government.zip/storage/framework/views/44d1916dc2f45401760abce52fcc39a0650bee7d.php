

<?php $__env->startSection('title-block'); ?>
    All Messages
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_moder_content'); ?>

<div class="d-flex justify-content-between align-items-center">
    <h2>Messages</h2>
</div>
<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th class = "text-uppercase">Name</th>
            <th class = "text-uppercase">Phone number</th>
            <th class = "text-uppercase">Email</th>
            <th class = "text-uppercase">Message</th>
            <th class = "text-uppercase">Details</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($message->id); ?></td>
            <td><?php echo e($message->name); ?></td>
            <td><?php echo e($message->phone_number); ?></td>
            <td><?php echo e($message->email); ?></td>
            <td><?php echo e($message->message); ?></td>
            <td>
                <button type="button" class="btn btn-dark" data-toggle="modal" data-target="#messageDetails"><i class="fas fa-info"></i></button>
            </td>
            <!--
            <div class="modal fade" th:id="messageDetails" tabindex="-1" role="dialog" aria-labelledby="messageDetailsTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="messageDetailsTitle">Message details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="" method="post" accept-charset="UTF-8">
                            <div class="modal-body">
                                <input type="hidden" name = "" value="">
                                <div class="form-group">
                                    <label class="text-uppercase"></label>
                                    <input type="text" class="form-control" name="" value="" readonly>
                                </div>
                                <div class="form-group">
                                    <label class="text-uppercase"></label>
                                    <input type="text" class="form-control" name="" value="" readonly>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            -->
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_moder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/admin_moder_messages.blade.php ENDPATH**/ ?>