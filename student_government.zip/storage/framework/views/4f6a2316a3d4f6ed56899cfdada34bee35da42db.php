

<?php $__env->startSection('title-block'); ?>
    Edit User
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin_moder_content'); ?>

<div class="card">
    <div class="card-body">
        <h5 class="card-title"><?php echo e(__('Name')); ?></h5>
        <p><?php echo e($user->name); ?></p>
        <h5 class="card-title"><?php echo e(__('Email')); ?></h5>
        <p><?php echo e($user->email); ?></p>
    </div>
    <div class="card-footer">
        <h5 class="card-title"><?php echo e(__('Roles')); ?></h5>
        <form action="<?php echo e(route ('admin.users.update', ['user' => $user->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>

            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" <?php echo e($user->hasAnyRole($role->role)?'checked':''); ?>>
                    <label><?php echo e($role->role); ?></label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit" class="btn btn-success">
                Update
            </button>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_moder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Alua\xampp\htdocs\student_government\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>